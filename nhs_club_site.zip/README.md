# NHS Club Website

Static, multi-page site for an NHS chapter.

## Pages
- `index.html` — Home (welcome)
- `hours.html` — Downloadable hours form + link to online form
- `officers.html` — Officer titles, names, and emails

## Customize
- Replace officer names/emails in `officers.html`.
- Replace the email address in the site footer in each file, or create a common include if using a generator.
- Replace `assets/nhs_hours_form.pdf` with your official form.
- Update the online hours form URL in `hours.html` (search for forms.gle).
- Edit colors and spacing in `styles.css`.

## Deploy
- **GitHub Pages**: Create a repo, upload these files, enable Pages from the repo settings.
- **Netlify/Vercel**: Drag-and-drop this folder into the dashboard, or connect the repo.
